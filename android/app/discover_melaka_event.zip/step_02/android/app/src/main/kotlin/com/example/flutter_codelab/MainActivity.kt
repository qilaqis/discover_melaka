package com.example.flutter_codelab

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
