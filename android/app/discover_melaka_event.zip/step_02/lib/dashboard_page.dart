import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'src/widgets.dart';
import 'app_state.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  User? currentUser;

  @override
  void initState() {
    super.initState();
    currentUser = _auth.currentUser;
  }

  Future<void> _signOut() async {
    await _auth.signOut();
    if (mounted) {
      Navigator.of(context).pushReplacementNamed('/');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Discover Melaka Events'),
        backgroundColor: Colors.deepOrange,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _signOut,
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome section
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.deepOrange.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome back!',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        color: Colors.deepOrange.shade700,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      currentUser?.displayName ?? currentUser?.email ?? 'Guest',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Colors.deepOrange.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              // Events section
              Text(
                'Upcoming Events',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              // Sample events
              Expanded(
                child: ListView(
                  children: [
                    EventCard(
                      title: 'Melaka Heritage Festival',
                      description: 'Celebrate the rich cultural heritage of Melaka with traditional performances, local cuisine, and historical exhibitions.',
                      date: DateTime.now().add(const Duration(days: 7)),
                      location: 'Jonker Street, Melaka',
                      attendingStatus: Attending.yes,
                      onAttendingChanged: (status) {
                        // Handle status change
                      },
                    ),
                    EventCard(
                      title: 'Nyonya Peranakan Culture Show',
                      description: 'Experience the unique Peranakan culture through traditional dances, music, and authentic Nyonya cuisine.',
                      date: DateTime.now().add(const Duration(days: 14)),
                      location: 'Peranakan Museum, Melaka',
                      attendingStatus: Attending.maybe, // Changed from unknown to maybe
                      onAttendingChanged: (status) {
                        // Handle status change
                      },
                    ),
                    EventCard(
                      title: 'River Cruise Night Market',
                      description: 'Enjoy a scenic river cruise followed by exploring the vibrant night market with local delicacies.',
                      date: DateTime.now().add(const Duration(days: 21)),
                      location: 'Melaka River, Melaka',
                      attendingStatus: Attending.no,
                      onAttendingChanged: (status) {
                        // Handle status change
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add new event functionality
        },
        backgroundColor: Colors.deepOrange,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}